### CREDITS
The following persons are credited for their contributions to the Splinter library:
- Anders Sandnes for his major contributions to the first drafts of the B-spline implementation.
- Patrick Robertson for his implementation of the penalized B-spline (P-spline).
- Anders Wenhaug for improving the DataTable data structure and for packaging the library with CMake.
- Aaron Trent for adding exception handling and generally improving the code.
